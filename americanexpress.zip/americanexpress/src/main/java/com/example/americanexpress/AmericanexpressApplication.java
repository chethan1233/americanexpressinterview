package com.example.americanexpress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmericanexpressApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmericanexpressApplication.class, args);
	}

}
